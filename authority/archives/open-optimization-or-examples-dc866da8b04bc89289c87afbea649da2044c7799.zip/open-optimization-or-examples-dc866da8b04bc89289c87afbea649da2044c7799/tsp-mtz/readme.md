TSP MTZ Model
